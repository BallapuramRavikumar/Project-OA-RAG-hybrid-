sudo  /usr/bin/neo4j  stop  --verbose
/etc/neo4j$ sudo nano  neo4j.conf