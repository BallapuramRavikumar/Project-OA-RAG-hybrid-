# Step 1: Install required libraries
# Uncomment the following line if running in a local environment
# !pip install langchain arxiv

# Step 2: Import necessary modules
from langchain_openai import OpenAI
from langchain_community.utilities import ArxivAPIWrapper
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
# Step 3: Initialize LangChain and arXiv Wrapper
llm = OpenAI(api_key='your_openai_api_key')  # Replace with your OpenAI API key
arxiv_tool = ArxivAPIWrapper(top_k_results = 3)
embeddings = OpenAIEmbeddings(openai_api_key='your key')
from langchain.chains import RetrievalQA
from langchain_openai import OpenAI
# Step 4: Function to handle user query and extract top 2 results
from langchain_community.document_loaders.arxiv import ArxivLoader

def load_arxiv_papers(category):
    query = f"cat:cond-mat.mtrl-sci.{category} AND submittedDate:[2023 TO 2024]"
    loader = ArxivLoader(query=query)

    # Load the documents lazily
    # for document in loader.lazy_load():
    #
    #     print(document)

    # Alternatively, get summaries as documents
    documents = loader.get_summaries_as_docs()
    pdf_data = []
    for doc in documents:
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=100)
        texts = text_splitter.create_documents([doc.page_content])
        pdf_data.extend(texts)
    # print(pdf_data)

    db = Chroma.from_documents(pdf_data, embeddings)
    return db
# Example usage
# user_input = "artificial based chips"  # This should be replaced with user input
# db = load_arxiv_papers(user_input)
#
# llm = OpenAI(openai_api_key='sk-proj-5LAyrM0AOxn3mh2WlgIAT3BlbkFJ9L8Jcc8jCi3QqKy2YVYu', model='gpt-3.5-turbo-instruct', temperature=0)
# qa = RetrievalQA.from_chain_type(llm=llm,
#                                  chain_type="stuff",
#                                  retriever=db.as_retriever())
#
# question = "PDA-NFL with 4.0x4.0 mm2 chip"
#
# result = qa({"query": question})
# print(result)
# Step 5: Example query and function call
# user_query = "artificial based chips"
# top_2_papers = get_top_2_arxiv_papers(user_query)
# print(top_2_papers)
# # Step 6: Display the top 2 papers
# for i, paper in enumerate(top_2_papers, 1):
#     print(f"Paper {i}:")
#     print(f"Title: {paper['title']}")
#     print(f"Authors: {', '.join(paper['authors'])}")
#     print(f"Abstract: {paper['summary']}\n")

# Note: Ensure you replace 'your_openai_api_key' with your actual OpenAI API key
