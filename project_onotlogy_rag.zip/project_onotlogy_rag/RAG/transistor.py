from neo4j import GraphDatabase
import pandas as pd

# Load the CSV file
file_path = '/home/abdul/Downloads/ResearchRabbit_Export_1716454477.csv'
df = pd.read_csv(file_path)

# Convert numeric columns to string before filling NaN values
for col in df.select_dtypes(include=['float64']).columns:
    df[col] = df[col].astype(str)

# Replace NaN values with empty strings
df.fillna('', inplace=True)

# Neo4j connection details
uri = "bolt://localhost:7687"  # Update with your Neo4j URI
user = "neo4j"  # Update with your Neo4j username
password = "manaf4071"  # Update with your Neo4j password


class Neo4jConnection:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def query(self, query, parameters=None):
        with self.driver.session() as session:
            return list(session.run(query, parameters))


def create_schema(conn):
    # Check if constraints exist before creating them
    existing_constraints = conn.query("CALL db.constraints()")
    existing_constraints = [constraint["name"] for constraint in existing_constraints]

    if 'constraint_Transistor_name' not in existing_constraints:
        conn.query("CREATE CONSTRAINT constraint_Transistor_name ON (t:Transistor) ASSERT t.name IS UNIQUE")

    if 'constraint_Paper_doi' not in existing_constraints:
        conn.query("CREATE CONSTRAINT constraint_Paper_doi ON (p:Paper) ASSERT p.doi IS UNIQUE")


def load_data(conn, df):
    # Create a Transistor node
    conn.query("MERGE (t:Transistor {name: 'Transistor'})")

    for index, row in df.iterrows():
        conn.query("""
        MERGE (p:Paper {doi: $doi})
        ON CREATE SET p.title = $title, p.abstract = $abstract, p.authors = $authors, p.journal = $journal, p.year = $year
        MERGE (t:Transistor {name: 'Transistor'})
        MERGE (t)-[:RELATED_TO]->(p)
        """, parameters={
            "doi": row['DOI'],
            "title": row['Title'],
            "abstract": row['Abstract'],
            "authors": row['Authors'],
            "journal": row['Journal'],
            "year": row['Year']
        })


def query_transistor_papers(conn, query_string):
    result = conn.query("""
    MATCH (t:Transistor {name: 'Transistor'})-[:RELATED_TO]->(p:Paper)
    WHERE p.title CONTAINS $query_string OR p.abstract CONTAINS $query_string
    RETURN p.title AS title, p.abstract AS abstract, p.authors AS authors, p.journal AS journal, p.year AS year
    """, parameters={"query_string": query_string})

    return result


def delete_transistor_node(conn):
    conn.query("""
    MATCH (t:Transistor)
    DETACH DELETE t
    """)


# Connect to Neo4j
conn = Neo4jConnection(uri, user, password)
# Create schema
create_schema(conn)

# Load data into Neo4j
load_data(conn, df)

# Query for papers related to transistors
query_string = "transistor"  # Example query string
results = query_transistor_papers(conn, query_string)

# Display results
for record in results:
    print(f"Title: {record['title']}\nAbstract: {record['abstract']}\nAuthors: {record['authors']}\nJournal: {record['journal']}\nYear: {record['year']}\n")

# Close the connection
conn.close()
# # Delete the Transistor node
# delete_transistor_node(conn)
#
# # Close the connection
# conn.close()
