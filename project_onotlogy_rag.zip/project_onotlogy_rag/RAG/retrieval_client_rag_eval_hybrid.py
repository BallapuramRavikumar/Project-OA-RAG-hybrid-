from langchain.vectorstores.neo4j_vector import Neo4jVector
from langchain.embeddings.openai import OpenAIEmbeddings
# embeddings_model = "text-embedding-ada-002"

import getpass
import os
import pandas as pd
import streamlit as st
from langchain.prompts import ChatPromptTemplate
from langchain_openai import OpenAI
from langchain.chains import RetrievalQA
os.environ["OPENAI_API_KEY"] = "api key"

from langchain_openai import ChatOpenAI
from langchain.chains import GraphCypherQAChain
from langchain.graphs import Neo4jGraph
from langchain.prompts import PromptTemplate, SystemMessagePromptTemplate
from arvix import  *
chat = ChatOpenAI(model="gpt-3.5-turbo-0125", api_key="api key",temperature=0)

graph = Neo4jGraph(
    url="bolt://localhost:7687",
    username="neo4j",
    password="manaf4071",
)

chain = GraphCypherQAChain.from_llm(
    ChatOpenAI(temperature=0),
    graph=graph,
    verbose=True
)

# Define the query that searches for the term in all properties of nodes
CYPHER_GENERATION_TEMPLATE = """
Task: Generate Cypher statement to query a graph database.
Instructions:
Use only the provided relationship types and properties in the schema.
Do not use any other relationship types or properties that are not provided.
{{question}}
# Custom query for searching term in all node properties
MATCH (n)
WITH n, keys(n) AS keys
UNWIND keys AS key
WITH n, key, n[key] AS value
WHERE toLower(toString(value)) CONTAINS toLower($question)
RETURN key, value AS property_value, 'Node' AS element_type, id(n) AS element_id
LIMIT 10

Please display only the property_value and form a text combining the value of the property value.

Note: Do not include any explanations or apologies in your responses.
Do not respond to any questions that might ask anything else than for you to construct a Cypher statement.
# Do not include any text except the generated Cypher statement.

The question is:
{question}
"""

CYPHER_GENERATION_PROMPT = PromptTemplate(
    input_variables=["question", "search"], template=CYPHER_GENERATION_TEMPLATE
)
review_template_str = """
Task: Generate new ideas and provide detailed explanations in the semiconductor and material science domains based on the given context.
Instructions:
1. Focus on generating innovative ideas or insights specifically related to semiconductors and material science.
2. Ensure explanations are clear, detailed, and easy to understand.
3. Avoid general topics; stay within the semiconductor and material science fields.

{context}
"""

prompt = SystemMessagePromptTemplate(
    prompt = PromptTemplate(

    input_variables=["context"],

    template=review_template_str,

))
messages = [prompt]


review_prompt_template = ChatPromptTemplate(

    input_variables=["context"],

    messages=messages,

)


# Define a function to run the query with a given search term
def run_query_with_search_term(search):
    # Create a parameterized query string

    # Initialize the GraphCypherQAChain with the ChatOpenAI model and Neo4j graph connection
    chain = GraphCypherQAChain.from_llm(
        ChatOpenAI(temperature=0),
        graph=graph,
        verbose=True,
        cypher_prompt=CYPHER_GENERATION_PROMPT
    )

    # Generate and run the query with the given search term
    query_result = chain.run(search)
    # Ensure the query result is correctly parsed
    if query_result:
        context = query_result.split(",")[-1].strip()  # Strip to remove any leading/trailing whitespace
    return  context
    #     print("Context:", context)
    #
    #     # Ensure chat is defined and correctly initialized
    #     review_chain = review_prompt_template | chat
    #     review_result = review_chain.invoke({"context": context})
    #     print("Review Result:", review_result)
    # else:
    #     print("No query result found")

    # # print("ee", query_result)
    # # ee
    # # # Extract the property values from the query result
    # # property_values = [result['property_value'] for result in query_result]
    #
    # # Generate a context-based response using the LLM
    # # context = " ".join(property_values)
    # context = query_result.split(",")[-1]
    # print("context", context)
    # review_chain = review_prompt_template | chat
    # review_chain.invoke({"context": context})


def combined_query_and_retrieve(search_term):
    # Run Cypher query
    cypher_result = run_query_with_search_term(search_term)
    if "I don't know" in cypher_result:
        cypher_result = " "

    # Load Arxiv papers
    db = load_arxiv_papers(search_term)
    stored_docs = db.similarity_search(search_term)
    print(db)
    for i, doc in enumerate(stored_docs):
        print(f"Document {i+1}:\n{doc.page_content}\n")

    llm = OpenAI(model='gpt-3.5-turbo-instruct', temperature=0)
    qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=db.as_retriever())
    result = qa({"query": search_term})


    combined_result = cypher_result + " " + result['result']
    print(type(combined_result))


    # # Combine the results
    # combined_content = cypher_result + " " + " ".join([doc.page_content for doc in db.retrieve()])

    # Initialize the LLM and QA chain

    # Run the QA chain with the combined content
    review_chain = review_prompt_template | chat
    result_final = review_chain.invoke({"context": combined_result})

    return combined_result, result_final.content


adv_answers = []
adv_contexts = []

questions_df = pd.read_csv("/home/abdul/project_onotlogy_rag/pythonProject1/questions_with_answers.csv")
from datasets import Dataset
# Process each question and store the result

for question in questions_df["Questions"]:

    context, response = combined_query_and_retrieve(question)
    adv_answers.append(response)
    adv_contexts.append([context])

test_questions = questions_df["Questions"].values.tolist()
test_groundtruths = questions_df["Answers"].values.tolist()
print(type(adv_contexts[0]))
response_dataset_advanced_retrieval = Dataset.from_dict({
    "question" : test_questions,
    "answer" : adv_answers,
    "contexts" : adv_contexts,
    "ground_truth" : test_groundtruths
})

from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    answer_correctness,
    context_recall,
    context_precision,
)

metrics = [
    faithfulness,
    answer_relevancy,
    context_recall,
    context_precision,
    answer_correctness,
]


advanced_retrieval_results = evaluate(response_dataset_advanced_retrieval, metrics,raise_exceptions=False)
print(advanced_retrieval_results)
# questions_df = pd.read_csv("/home/abdul/Downloads/questions.csv")
#
# # Process each question and store the result
# answers = []
# for question in questions_df["Questions"]:
#     result = combined_query_and_retrieve(question)
#     answers.append(result.content)
#
#
# # Add the answers to the DataFrame
# questions_df["Answers"] = answers
#
# # Save the updated DataFrame to a new CSV file
# output_path_with_answers = "questions_with_answers_2.csv"
# questions_df.to_csv(output_path_with_answers, index=False)
# Streamlit UI
# ===============
# st.set_page_config(page_title="Doc Searcher", page_icon=":robot:")
# st.header("Query PDF Source")
#
# form_input = st.text_input('Enter Query')
# submit = st.button("Generate")
#
# if submit:
#     st.write(combined_query_and_retrieve(form_input))
# Run the query with the search term "periodic structure of a crystal"
# search_term = "PDA-NFL with 4.0x4.0 mm2 chip"  # User input for search term
# # arxiv_category = "PDA-NFL with 4.0x4.0 mm2 chip"  # User input for Arxiv category
# result = combined_query_and_retrieve(search_term)
# print(result)
