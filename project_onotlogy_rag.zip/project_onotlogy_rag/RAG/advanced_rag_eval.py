from langchain_openai import OpenAI
from langchain_community.utilities import ArxivAPIWrapper
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
import os
from langchain_community.document_transformers.embeddings_redundant_filter import EmbeddingsRedundantFilter
from langchain.retrievers.document_compressors import DocumentCompressorPipeline
from langchain.retrievers import ContextualCompressionRetriever
from langchain_community.document_transformers.long_context_reorder import LongContextReorder
from langchain.retrievers.multi_query import MultiQueryRetriever
# Step 3: Initialize LangChain and arXiv Wrapper
os.environ["OPENAI_API_KEY"] = "yout key"


from langchain_community.vectorstores import Chroma
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter, RecursiveCharacterTextSplitter
from langchain.retrievers import BM25Retriever, EnsembleRetriever
from langchain.retrievers import ContextualCompressionRetriever
from bge import  BgeRerank

embeddings = OpenAIEmbeddings(openai_api_key='your key')
openai_llm = OpenAI(temperature=0)
pdf_folder_path = "/home/abdul/project_onotlogy_rag/pythonProject1/documnets"
# df_folder_path = "/home/abdul/project_onotlogy_rag/pythonProject1/documnets"
documents = []
for file in os.listdir(pdf_folder_path):
    if file.endswith('.pdf'):
        pdf_path = os.path.join(pdf_folder_path, file)
        print(f"Processing {pdf_path}")
        loader = PyPDFLoader(pdf_path)
        documents.extend(loader.load())
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=10)
chunked_documents = text_splitter.split_documents(documents)
vectorstore = Chroma(embedding_function=embeddings,
                 persist_directory="Vectorstore/chromadb",
                 collection_name="full_documents")
vectorstore.add_documents(chunked_documents)
vectorstore.persist()


bm25_retriever = BM25Retriever.from_documents(chunked_documents)
bm25_retriever.k=10


#
vs_retriever = vectorstore.as_retriever(search_kwargs={"k":10})
#

ensemble_retriever = EnsembleRetriever(retrievers=[bm25_retriever,vs_retriever],
                                       weight=[0.5,0.5])
#

redundant_filter = EmbeddingsRedundantFilter(embeddings=embeddings)
#
reordering = LongContextReorder()
#
reranker = BgeRerank()
#
pipeline_compressor = DocumentCompressorPipeline(transformers=[redundant_filter,reordering,reranker])
#
compression_pipeline = ContextualCompressionRetriever(base_compressor=pipeline_compressor,
                                                      base_retriever=ensemble_retriever)

from langchain.chains import RetrievalQA
import pandas as pd
from datasets import Dataset
#
qa_advanced = RetrievalQA.from_chain_type(llm=openai_llm,
                                 chain_type="stuff",
                                 retriever=compression_pipeline,
                                 return_source_documents=True)

adv_answers = []
adv_contexts = []

questions_df = pd.read_csv("/home/abdul/project_onotlogy_rag/pythonProject1/questions_with_answers.csv")

# Process each question and store the result

for question in questions_df["Questions"]:
  response = qa_advanced.invoke({"query" : question})
  adv_answers.append(response["result"])
  adv_contexts.append([context.page_content for context in response['source_documents']])

test_questions = questions_df["Questions"].values.tolist()
test_groundtruths = questions_df["Answers"].values.tolist()

response_dataset_advanced_retrieval = Dataset.from_dict({
    "question" : test_questions,
    "answer" : adv_answers,
    "contexts" : adv_contexts,
    "ground_truth" : test_groundtruths
})

from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    answer_correctness,
    context_recall,
    context_precision,
)

metrics = [
    faithfulness,
    answer_relevancy,
    context_recall,
    context_precision,
    answer_correctness,
]


advanced_retrieval_results = evaluate(response_dataset_advanced_retrieval, metrics,raise_exceptions=False)
print(advanced_retrieval_results)


